//
//  UIImage+image.h
//  text1
//
//  Created by Apple on 2016/10/25.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (image)
//__kindof  用这个方法修饰返回值,说明可以返回他的子类
+(__kindof UIImage*)qyp_imageNamed:(NSString *)imageName;
@end
