//
//  ViewController.m
//  text1
//
//  Created by Apple on 2016/10/25.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+image.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    [UIImage imageNamed:@"123"];
    
    //imageName:
    //实现方法:底层调用qyp_imageName
    //本质:交换两个方法的实现imageName和qyp_imageNamed方法
    //调用imageNamed其实就是调用qyp_imageNamed
    
    //imageNamed加载图片,并不知道图片加载成功了
    //以后调用imageNamed的时候,就知道图片是否加载
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
