//
//  UIImage+image.m
//  text1
//
//  Created by Apple on 2016/10/25.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "UIImage+image.h"
#import <objc/message.h>
@implementation UIImage (image)
//加载这个分类的时候调用
+(void)load{
    NSLog(@"%s",__func__);
    
    //交换方法实现,方法都是定义在类里面
    // class_getMethodImplementation 获取类方法的实现
    //class_getInstanceMethod获取对象方法
    //class_getClassMethod 获取类方法
    
    //imageName
    //Class:获取那个类方法
    //SEL:获取方法编号,根据SEL就能够去对应的累着方法
    Method imageNameMethod =  class_getClassMethod([UIImage class], @selector(imageNamed:));
    
    Method qyp_imageNameMethod =  class_getClassMethod([UIImage class], @selector(qyp_imageNamed:));
    
    
    //交换方法的实现
    method_exchangeImplementations(imageNameMethod, qyp_imageNameMethod);
    
}
//运行时
//先写一个其他方法,实现这个功能


//在分类里面不能调用super,分类木有父类
//+(UIImage*)imageNamed:(NSString *)name{
//    [super im]
//}

+(UIImage*)qyp_imageNamed:(NSString *)imageName{
    //1加载图片
    UIImage *image = [UIImage qyp_imageNamed:imageName];
    
    //2判断更能
    if (image == nil) {
        NSLog(@"加载图片为空");
    }
    return image;
}
@end
